package com.fast.app.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fast.app.entity.User;
import com.fast.app.mapper.UserMapper;
import com.fast.app.service.IUserService;
import com.fast.util.RedisUtils;

/**
 * <p>
 * 用户信息表 服务实现类
 * </p>
 *
 * @author xiapengyu
 * @since 2019-06-20
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
	
	@Resource
	protected RedisUtils redisUtils;

	@Override
    public User findByPhoneNumber(String phoneNumber) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("phone_number", phoneNumber);
        return this.getOne(queryWrapper);
    }

}

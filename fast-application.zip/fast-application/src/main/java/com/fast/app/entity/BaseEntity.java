package com.fast.app.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fast.util.JsonUtil;

import lombok.Data;

@Data
public class BaseEntity {
    @TableField(exist = false)
    public int pageIndex;
    @TableField(exist = false)
    public int pageSize;
    
    public String toString() {
		return JsonUtil.toJsonString(this);
	}

}

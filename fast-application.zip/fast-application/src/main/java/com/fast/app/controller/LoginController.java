package com.fast.app.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fast.app.dto.ResponseDto;
import com.fast.app.dto.SecurityContext;
import com.fast.app.dto.UserDto;
import com.fast.app.entity.User;
import com.fast.app.service.IUserService;
import com.fast.common.Constant;
import com.fast.util.RedisUtils;
import com.fast.util.UUIDUtil;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/login")
public class LoginController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IUserService userService;
	
	@Resource
	private RedisUtils redisUtils;
	
	@ApiOperation(value = "手机验证码登录")
    @RequestMapping(value = "/loginByCode", method = RequestMethod.POST)
    public ResponseDto loginByCode(@RequestBody UserDto user) {
		if("123456".equals(user.getValidateCode())) {
			User loginUser = userService.findByPhoneNumber(user.getPhoneNumber());
			String token = UUIDUtil.getUUID();
			logger.info("登录用户信息>>[{}], Token>>[{}]", loginUser, token);
			String key = Constant.REDIS_KEY_USER + token;
			redisUtils.setOriginWithPreExpire(key, loginUser);
			SecurityContext.setUserPrincipal(loginUser);
			return new ResponseDto(Constant.SUCCESS_CODE, token, "登录成功");
		}else {
			return new ResponseDto(Constant.SUCCESS_CODE, null, "验证码错误，请重新尝试");
		}
	}
	
	@ApiOperation(value = "用户退出登录")
    @RequestMapping(value = "/loginout", method = RequestMethod.POST)
    public ResponseDto loginout(@RequestBody UserDto user) {
		if("123456".equals(user.getValidateCode())) {
			User loginUser = userService.findByPhoneNumber(user.getPhoneNumber());
			String token = UUIDUtil.getUUID();
			logger.info("登录用户信息>>[{}], Token>>[{}]", loginUser, token);
			String key = Constant.REDIS_KEY_USER + token;
			redisUtils.setOriginWithPreExpire(key, loginUser);
			SecurityContext.setUserPrincipal(loginUser);
			return new ResponseDto(Constant.SUCCESS_CODE, token, "登录成功");
		}else {
			return new ResponseDto(Constant.SUCCESS_CODE, null, "验证码错误，请重新尝试");
		}
	}
	
}

package com.fast.app.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.fast.app.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户信息表
 * </p>
 *
 * @author xiapengyu
 * @since 2019-06-20
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("tb_user")
public class User extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 用户id
	 */
	@TableId(value = "user_id", type = IdType.AUTO)
	private Integer userId;

	/**
	 * 用户名
	 */
	private String userName;

	/**
	 * 手机号码
	 */
	private String phoneNumber;

	/**
	 * 密码
	 */
	private String password;

	/**
	 * 性别0未知1男2女
	 */
	private Integer gender;

	/**
	 * 0 普通用户1VIP用户2高级VIP用户
	 */
	private Integer userLevel;

	/**
	 * 昵称
	 */
	private String nickName;

	/**
	 * 数据签名
	 */
	private String userSign;

	/**
	 * 用户余额
	 */
	private BigDecimal userAmount;

	/**
	 * 充值总金额
	 */
	private BigDecimal rechargeAmount;

	/**
	 * 消费总金额
	 */
	private BigDecimal consumeAmount;

	/**
	 * 身份证号
	 */
	private String idCard;

	/**
	 * 身份证正面
	 */
	private String idcardFront;

	/**
	 * 身份证背面
	 */
	private String idcardBack;

	/**
	 * 执照图片
	 */
	private String userLicense;

	/**
	 * 头像
	 */
	private String avatar;

	/**
	 * 地址
	 */
	private String address;

	/**
	 * 会员类型1医生2机构3患者
	 */
	private Integer type;

	/**
	 * 0 可用1禁用2注销
	 */
	private Integer status;

	/**
	 * 介绍
	 */
	private String introduce;

	/**
	 * 是否认证1认证0未认证
	 */
	private Integer isCertification;

	/**
	 * 粉丝数量
	 */
	private Integer fanCount;

	/**
	 * 最后一次登录ip
	 */
	private String lastLoginIp;

	/**
	 * 最后一次登陆时间
	 */
	private LocalDateTime lastLoginTime;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;

	/**
	 * 更新时间
	 */
	private LocalDateTime updateTime;

	/**
	 * 删除标记1未删除0删除
	 */
	private Integer deleteFlag;

}

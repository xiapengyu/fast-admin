package com.fast.app.dto;

import com.fast.app.entity.User;

public class UserDto extends User {
	
	private static final long serialVersionUID = 1L;
	/**
	 * 用于登陆的手机验证码
	 */
	private String validateCode;
	
	public String getValidateCode() {
		return validateCode;
	}
	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}
	
	
}

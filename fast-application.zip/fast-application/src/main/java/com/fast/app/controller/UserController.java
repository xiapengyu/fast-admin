package com.fast.app.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fast.app.dto.ResponseDto;
import com.fast.app.dto.UserDto;
import com.fast.app.entity.User;
import com.fast.app.service.IUserService;
import com.fast.common.Constant;

import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 用户信息表 前端控制器
 * </p>
 *
 * @author xiapengyu
 * @since 2019-06-20
 */
@RestController
@RequestMapping("/app/user")
public class UserController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IUserService userService;
	
	@ApiOperation(value = "获取用户信息")
    @RequestMapping(value = "/queryUserInfo", method = RequestMethod.POST)
    public ResponseDto queryUserInfo(@RequestBody UserDto user) {
		logger.info("查询用户信息>>[{}]", user);
		ResponseDto response = new ResponseDto(Constant.SUCCESS_CODE, null, "");
		User loginUser = userService.findByPhoneNumber(user.getPhoneNumber());
		logger.info("查询用户信息结果>>[{}]", loginUser);
		response.setData(loginUser);
		return response;
	}
}

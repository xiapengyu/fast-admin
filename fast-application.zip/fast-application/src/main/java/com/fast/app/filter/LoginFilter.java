package com.fast.app.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fast.app.dto.ResponseDto;
import com.fast.common.Constant;
import com.fast.util.JsonUtil;

@WebFilter(urlPatterns = "/app/*", filterName = "loginFilter")
public class LoginFilter implements Filter {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		String token = req.getHeader("Authorization");
		//校验token为空或者redis缓存中不存在，提示登录失败
		if(StringUtils.isEmpty(token)) {
			logger.info("token无效，请重新登录");
			resp.setHeader("Content-type", "application/json;charset=UTF-8");
			resp.setCharacterEncoding("UTF-8");
			String msg = JsonUtil.toJsonString(new ResponseDto(Constant.SUCCESS_CODE, null, "请重新登录"));
			response.getWriter().print(msg);
		}else {
			chain.doFilter(request, response);
		}
	}

}

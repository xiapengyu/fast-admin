package com.fast.app.service;

import com.fast.app.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户信息表 服务类
 * </p>
 *
 * @author xiapengyu
 * @since 2019-06-20
 */
public interface IUserService extends IService<User> {

	User findByPhoneNumber(String phoneNumber);
	
}

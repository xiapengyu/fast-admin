package com.fast.app.dto;

import com.fast.app.entity.User;

/**
 * Security Context
 * 
 */
public class SecurityContext {

	private static ThreadLocal<User> userThreadLocal = new ThreadLocal<>();
	private static ThreadLocal<String> tokenLocal = new ThreadLocal<>();
	private static ThreadLocal<String> frontTypeLocal = new ThreadLocal<>();

	private SecurityContext() {

	}

	public static Integer getUserId() {
		return getUserPrincipal() != null ? getUserPrincipal().getUserId() : null;
	}

	public static String getUserName() {
		return getUserPrincipal() != null ? getUserPrincipal().getUserName() : null;
	}

	public static User getUserPrincipal() {
		return userThreadLocal.get();
	}

	public static void setUserPrincipal(User user) {
		userThreadLocal.set(user);
	}

	public static String getToken() {
		return tokenLocal.get();
	}

	public static void setToken(String token) {
		tokenLocal.set(token);
	}

	public static String getFrontType() {
		return frontTypeLocal.get();
	}

	public static void setFrontType(String frontType) {
		frontTypeLocal.set(frontType);
	}

	public static void cleanContext() {
		userThreadLocal.remove();
		tokenLocal.remove();
		frontTypeLocal.remove();
	}
}

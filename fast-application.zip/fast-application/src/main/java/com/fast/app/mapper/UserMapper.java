package com.fast.app.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fast.app.entity.User;

/**
 * <p>
 * 用户信息表 Mapper 接口
 * </p>
 *
 * @author xiapengyu
 * @since 2019-06-20
 */
public interface UserMapper extends BaseMapper<User> {

}

package com.fast.common;

public class Constant {
	
	public static final String REDIS_KEY_USER = "AUTH:USER_";
	
    public static final String PARMS_ERROR_CODE = "00001";
    public static final String PARMS_ERROR_MSG = "参数错误";
    public static final String SYSTEM_ERROR_MSG = "系统内部错误";
    public static final String PARMS_CHECK_MSG = "参数填写有误,请检查各项参数是否正确";

    public static final String SUCCESS_CODE = "00000";
    public static final String SUCCESS_MESSAGE = "success";

    public static final String COMMON_ERROR_CODE = "00002";
    public static final String NO_LOGIN_ERROR_MESSAGE = "没有用户权限";

    public static final String OTHER_ERROR_CODE = "10000";
    public static final String UPDATE_FAIL = "update fail";

    public static final short DELETE_FLAG_VALUE_1 = 1;
    public static final short DELETE_FLAG_VALUE_0 = 0;
    public static final String JOB_RUN_FAIL = "JOB执行失败";


    //****订单状态********//
    /**
     * 充电状态(1:建立订单;2:充电中;3:正在停止充电;4:充电结束;5:预约中;55:断线重连中)';
     */
    public static final short CS_STARING = 1;//创建订单
    public static final short CS_CHARGING = 2;//充电中
    public static final short CS_STOPING = 3;//停止充电中
    public static final short CS_FINISH = 4;//充电已停止
    public static final short CS_SCHEDULING = 5;//预约中
    public static final short CS_RECONNECT = 55;//断线重连中

    /**
     * 对账状态
     */
    public static final short BILL_UNCHECK = 0;//未对账
    public static final short BILL_CHECKED = 1;//已对账

    /**
     * 支付状态
     */
    public static final short PAY_STATUS_0 = 0;//未支付
    public static final short PAY_STATUS_1 = 1;//已支付

    /**
     * 支付方式
     */
    public static final short PAY_TYPE_WEIXIN = 1;//微信支付
    public static final short PAY_TYPE_ALIPAY = 2;//支付宝支付

    /**
     * 支付方式名称
     */
    public static final String PAY_TYPE_WEIXIN_NAME = "微信";
    public static final String PAY_TYPE_ALIPAY_NAME = "支付宝";

    public static final String BILL_TYPE_RECHARGESTATEMENT = "rechargeStatement";
    public static final String BILL_TYPE_RECHARGE = "recharge";
    public static final String BILL_TYPE_CONSUMESTATEMENT = "consumeStatement";
    public static final String BILL_TYPE_CONSUME = "consume";
    public static final String TRANSFORMER_REPORT_DATA = "transformerReport";

    /**
     * 充电桩启用命令参数
     */
    public static final String SWITCH_ENABLE_COMMOND = "enable";
    /**
     * 充电桩禁用命令参数
     */
    public static final String SWITCH_DISABLE_COMMOND = "disable";
    /**
     * 充电桩启用命令参数
     */
    public static final String SWITCH_SUSPEND_COMMOND = "suspend";
    /**
     * 充电桩禁用命令参数
     */
    public static final String SWITCH_RESUME_COMMOND = "resume";

    /**
     * 计费规则在redis中存储的主键前缀
     */
    public static final String REDIS_KEY_CHARGING_RULES_INFO = "RESPCMD:CHARGINGRULES:INFO-";



    public static final String DEFAULT_STATION_UUID = "0";

    /**
     * 在线离线状态
     */
    public static final short ONOFFLINE_STATE_OFFLINE = 0;//离线
    public static final short ONOFFLINE_STATE_ONLINE = 1;//在线

    public static final short CHARGING_STATE_ISCHARGING = 1;//充电中
    public static final short CHARGING_STATE_IDEL = 0;//空闲
    
    public static final String INNER_ERROR = "内部错误，请联系工作人员处理";
    
    public static final String PILE_OCCUPIED_ERROR = "该充电插座被占用，请更换充电插座";
    
    public static final String CHARGING_END_ERROR = "非常抱歉，充电插座发生异常，充电已停止。";
    
    /**
     * 订单已经建立但还未开始充电
     */
    public static final Short CREATED_BILL = 1;
    
    /**
     * 订单正在充电、正在停止之中、正在预约中
     */
    public static final Short RUNNING_BILL = 2;
    
    public static final int CONSUME_AMOUNT_LIMIT = 5;
    
    public static final String SUCCESS_MSG = "success";
    public static final String ERROR_MSG = "fail";
    /**
     * 设备状态开始升级
     */
    public static final short DEVICE_STATUS_FAULT_UPGRADE = 2;
    /**
     * 设备状态升级成功
     */
    public static final short DEVICE_STATUS_FAULT_UPGRADE_SUCCESS = 3;
    /**
     * 设备状态升级失败
     */
    public static final short DEVICE_STATUS_FAULT_UPGRADE_FAILED = 4;
    /**
     * 高峰
     */
    public static final short FEE_RULE_STAGE_1 = 1;
    /**
     * 平峰
     */
    public static final short FEE_RULE_STAGE_2 = 2;
    /**
     * 低谷
     */
    public static final short FEE_RULE_STAGE_3 = 3;


    /**
     * 集团大屏REDISkey
     */
    //用户活跃度
    public static final String USER_RACTIVITY = "USER:USER_ACTIVITY";

    // 最近24小时数据
    public static final String HOUR_STATISTICS_DATA = "SCREENGROUP:HOURSTATISTICSDATA";

    //最近30天数据
    public static final String DAY30_STATISTICS_DATA = "SCREENGROUP:DAY30STATISTICSDATA";
    //最近180天数据
    public static final String DAY180_STATISTICS_DATA = "SCREENGROUP:DAY180STATISTICSDATA";
    //充电电量
    public static final String CHARGE_POWER = "SCREENGROUP:CHARGEPOWER";
    //居民用电功率
    public static final String HOUSE_POWER = "SCREENGROUP:HOUSEPOWER";
    //存储分钟统计次数
    //总的
    public static final String MINUTE_COUNT1 = "SCREENGROUP:MINUTE_COUNT1";
    //各个小区
    public static final String MINUTE_COUNT2 = "SCREENGROUP:MINUTE_COUNT2";
    //小区数据redis缓存
    public static final String COURT_LIST = "SCREENGROUP:COURTLIST";
    //存储各小区充电的瞬时功率
    public static final String COURT_CHARGEPOWER = "SCREENGROUP:COURTCHARGEPOWER";
    //存储各小区房屋用电的瞬时功率
    public static final String COURT_HOUSEPOWER = "SCREENGROUP:COURTHOUSEPOWER";
    //集团大屏总的数据,stationUuid
    public static final String ALLCOURTNAME = "00000000000000000000000000000000";
    //三级页面小区设备变压器负载情况
    public static final String TRANSFORMER_LOAD ="SCREENGROUP:TRANSFORMERLOAD";
    //三级页面回路负载情况
    public static final String ELEC_LOAD ="SCREENGROUP:ELECLOAD";
    //变压器回路映射关系
    public static final String AMMETER_LOAD="SCREENGROUP:AMMETER_LOAD";
    //回路负载排名列表
    public static final String ELEC_RANK = "SCREENGROUP:ELECRANK";
    //储存24小时调峰电量
    public static final String CONTROL_KWH = "SCREENGROUP:CONTROL_KWH";
    //储存设备的信息
    public static final String CHARGEPILE_INFO_PRE = "CHA:SCREENGROUP:CHARGEPILE_INFO:";
    //============================================

}
